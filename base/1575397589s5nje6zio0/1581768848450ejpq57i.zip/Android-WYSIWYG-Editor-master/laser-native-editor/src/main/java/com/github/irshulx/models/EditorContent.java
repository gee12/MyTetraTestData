package com.github.irshulx.models;

import java.util.List;

/**
 * Created by mkallingal on 2/4/2016.
 */
public class EditorContent {
    public List<Node> nodes;
}

