package com.github.irshulx.models;

public enum EditorType{
    hr,
    ul,
    ol,
    UL_LI,
    OL_LI,
    img,
    IMG_SUB,
    INPUT,
    map,
    macro
}
