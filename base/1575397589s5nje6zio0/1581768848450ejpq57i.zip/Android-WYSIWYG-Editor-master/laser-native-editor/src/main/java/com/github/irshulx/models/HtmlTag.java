package com.github.irshulx.models;

public enum HtmlTag{
    h1,
    h2,
    h3,
    ul,
    ol,
    br,
    img,
    hr,
    p,
    div,
    blockquote
}
