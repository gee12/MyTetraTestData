package com.github.irshulx.models;

/**
 * Created by mkallingal on 5/18/2016.
 */
public class ImageResponse {
       public String Uri;
        public int HttpStatusCode;
    public String Message;
    }
