package com.github.irshulx.models;

public enum Op{
    Insert,
    Delete,
    Update
}
