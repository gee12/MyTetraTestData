package com.github.irshulx.models;

/**
 * Created by mkallingal on 1/14/2016.
 */


public enum RenderType {
    Renderer,
    Editor
}
