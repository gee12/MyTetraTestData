package com.github.irshulx.models;

public enum TextSetting {
    TEXT_COLOR,
}
