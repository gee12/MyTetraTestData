package com.github.irshulx.models;

public enum TextStyle {
    BOLD,ITALIC,UNDERLINED,STRIKETHROUGH,NORMAL,BIG,BIGGERTEXT;
}
